﻿-- [[
-- Language: French
-- Translated by: 
-- Last Updated: 
-- ]]
--------------------------
-- Translatable strings --
--------------------------
if (GetLocale() == "frFR") then

end
