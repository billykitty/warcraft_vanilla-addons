﻿-- [[
-- Language: Korean
-- Translated by: 
-- Last Updated: 
-- ]]
--------------------------
-- Translatable strings --
--------------------------
if (GetLocale() == "koKR") then

end
