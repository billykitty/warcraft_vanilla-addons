-- [[
-- Language: German
-- Translated by:  Killekille of Blackrock
-- Last Updated:  2006/12/22 00:05
-- ]]
--------------------------
-- Translatable strings --
--------------------------
if (GetLocale() == "deDE") then
FQ_VERSION = "2.11.205";
--
FQ_FORMAT0 = 		"QuestName";
FQ_FORMAT1 = 		"[QuestLevel] QuestName";
FQ_FORMAT2 =		"[QuestLevel+] QuestName";
FQ_FORMAT3 =		"[QuestLevel] QuestName (Tag)";
--
FQ_EPA_PATTERN1 = 	"^(.+): %s*[-%d]+%s*/%s*[-%d]+%s*$";
FQ_EPA_PATTERN2 = 	"^(.+)\(Ist fertig\)%s$";
FQ_EPA_PATTERN3 = 	"^(.+)[^Trade]fertig.$";
FQ_EPA_PATTERN4 = 	"^Erfahrung gewonnen�: .+$";
FQ_EPA_PATTERN5 = 	"^Entdeckt: .+$";
FQ_EPA_PATTERN6 = 	"^(.+)\(Fertig\)%s$";
FQ_EPA_PATTERN7 = 	"^Quest angenommen: .+$";
--
FQ_QUEST_TEXT =		"(.*): %s*([-%d]+)%s*/%s*([-%d]+)%s*$";
--
FQ_LOADED = 		"|cff00ffffFastQuest "..FQ_VERSION.." ist nun geladen. Gib /fq ein f\195\188r mehr Details.";
FQ_INFO =			"|cff00ffffFastQuest: |r|cffffffff";
--
FQ_INFO_QUEST_TAG =		"Anzeige der Quest-Tags im QuestTracker wurde ";
FQ_INFO_AUTOADD = 		"Automatisches Hinzuf\195\188gen/Entfernen von ge\195\164nderten Quests zum QuestTracker wurde ";
FQ_INFO_AUTONOTIFY = 	"Automatische Benachrichtigung der Gruppenmitglieder \195\188ber deinen Quest-Fortschritt wurde ";
FQ_INFO_AUTOCOMPLETE = 	"Automatisches Quest beenden wurde ";
FQ_INFO_ALLOWGUILD = 	"Automatische Benachrichtigung der Gilden-Mitglieder \195\188ber deinen Quest-Fortschritt wurde ";
FQ_INFO_ALLOWRAID = 	"Automatische Benachrichtigung der Raid-Mitglieder \195\188ber deinen Quest-Fortschritt wurde";
FQ_INFO_ALWAYSNOTIFY = 	"Immer \195\188ber Quest-Fortschritt benachrichtigen wurde ";
FQ_INFO_DETAIL =		"Benachrichtigung \195\188ber Details zum Questfortschritt wurde ";
FQ_INFO_LOCK =			"Bewegbare Komponenten wurden |cffff0000gesperrt|r|cffffffff";
FQ_INFO_UNLOCK =		"Bewegbare Komponenten wurden |cff00ff00entsperrt|r|cffffffff";
FQ_INFO_NODRAG =		"Ziehen ist jetzt ";
FQ_INFO_RESET = 		"Bewegbare Komponenten wurden zur\195\188ckgesetzt";
FQ_INFO_FORMAT =		"Zwischen Ausgabeformaten umschalten ";
FQ_INFO_DISPLAY_AS =	"Gew\195\164hltes Format: ";
FQ_INFO_CLEAR =			"Alle Quest-Tracker Quests wurden gel\195\182scht ";
FQ_INFO_USAGE = 		"|cffffff00benutze: /fastquest [befehl] oder /fq [befehl]|r|cffffffff";
FQ_INFO_COLOR =			"Quest-Titel in anderer Farbe anzeigen wurde ";
--
FQ_MUST_RELOAD =		"Das UI muss neu geladen werden, damit die \195\132nderungen wirksam werden. Gib /console reloadui ein";
--
FQ_USAGE_TAG =			"Anzeige der Quest-Tags umschalten (Elite, Raid, etc.) ";
FQ_USAGE_LOCK =			"(ent)sperrt das Quest-Tracker-Fenster.";
FQ_USAGE_NODRAG =		"Ziehen des Quest-Trackers umschalten; UI neu laden, damit die \195\132nderung wirksam wird.";
FQ_USAGE_AUTOADD =		"Umschalten des automatischen Hinzuf\195\188gens von ge\195\164nderten Quests zum Quest-Tracker.";
FQ_USAGE_AUTONOTIFY =	"Umschalten der automatischen Benachrichtigung von Gruppenmitgliedern.";
FQ_USAGE_AUTOCOMPLETE =	"Umschalten der automatischen Beendigung von Quests beim Abgeben. (Die Beenden-Meldung des NPC wird dabei nicht angezeigt!!)";
FQ_USAGE_ALLOWGUILD =	"Umschalten der automatischen Benachrichtigung von Gilden-Mitgliedern.";
FQ_USAGE_ALLOWRAID =	"Umschalten der automatischen Benachrichtigung von Raid-Mitgliedern.";
FQ_USAGE_ALWAYSNOTIFY =	"Umschalten der automatischen Benachrichtigung im allgemeinen Channel.";
FQ_USAGE_DETAIL =		"Umschalten zwischen kurzer und detaillierter Quest-Benachrichtigung.";
FQ_USAGE_RESET =		"Zur\195\188cksetzen der beweglichen Komponenten von FastQuest (Ziehen muss aktiviert sein).";
FQ_USAGE_STATUS =		"Den FastQuest Konfigurationsstatus anzeigen.";
FQ_USAGE_CLEAR =		"QuestTracker-Fenster aus allen Quests l\195\182schen.";
FQ_USAGE_FORMAT =		"Ausgabeformat der Benachrichtigungen umschalten.";
FQ_USAGE_COLOR =		"Farbigen Quest-Titel im Quest-Tracker-Fenster umschalten.";
--
FQ_BINDING_CATEGORY_FASTQUEST		= "Quest Erweiterung";
FQ_BINDING_HEADER_FASTQUEST			= "FastQuest";
FQ_BINDING_NAME_FASTQUEST_T			= "Quest Tag";
FQ_BINDING_NAME_FASTQUEST_F			= "Quest Format";
FQ_BINDING_NAME_FASTQUEST_AOUTP		= "Auto-Benachrichtigung Gruppe";
FQ_BINDING_NAME_FASTQUEST_AOUTC		= "Auto-Best\195\164tigen Quest";
FQ_BINDING_NAME_FASTQUEST_AOUTA		= "Auto-Hinzuf\195\188gen QuestTracker";
FQ_BINDING_NAME_FASTQUEST_NOHEADERS	= "Lock/Unlock QuestTracker";
--
FQ_SELECT_FORMAT =		"Format ausw\195\164hlen";
--
FQ_QUEST_PROGRESS =		"Quest-Fortschritt: ";
--
FQ_QUEST = 				"FastQuest: ";
FQ_QUEST_ISDONE =		" ist nun fertig!";
FQ_QUEST_COMPLETED =	" (FERTIG)";
FQ_DRAG_DISABLED =		"Fast Quest: Ziehen ist ausgeschaltet, benutze /fq nodrag zum Umschalten. Das UI muss danach neu geladen werden";
--
FQ_ENABLED =			"|cff00ff00eingeschaltet|r|cffffffff";
FQ_DISABLED =			"|cffff0000ausgeschaltet|r|cffffffff";
FQ_LOCK =				"|cffff0000gesperrt|r|cffffffff";
FQ_UNLOCK =				"|cff00ff00entsperrt|r|cffffffff";
end
